const btn=document.getElementById('openBtn');
const manual=document.getElementById('manual');
btn.onclick=()=>{manual.classList.remove('hidden');manual.scrollIntoView({behavior:'smooth'})};

const target=new Date('2026-12-12T00:00:00').getTime();
const timer=document.getElementById('timer');
function tick(){
const now=Date.now();
const d=target-now;
if(d<=0){timer.textContent='Chegou o grande dia!';return;}
const days=Math.floor(d/86400000);
const hours=Math.floor(d%86400000/3600000);
const mins=Math.floor(d%3600000/60000);
const secs=Math.floor(d%60000/1000);
timer.textContent=`${days} dias ${hours}h ${mins}m ${secs}s`;
}
tick();
setInterval(tick,1000);
